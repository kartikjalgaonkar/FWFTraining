package com.java.main;

import java.util.List;
import java.util.Optional;
import java.util.Scanner;

import com.java.dto.Book;
import com.java.factory.BookCategoryFactory;
import com.java.service.BookLibrary;

public class BookMain {
	public static void main(String[] args) {

		System.out.println("Please enter a book category to get details");

		Scanner sc = new Scanner(System.in);
		String category = sc.next();
		Book b = new Book();
		b.setBookCategory(category);

		BookLibrary bl = BookCategoryFactory.getBookCategory(category);
		Optional<BookLibrary> optional = Optional.ofNullable(bl);
		if (optional.isPresent()) {
			List<Book> list = bl.serachByCategory(b);
			list.stream().forEach(System.out::println);
			System.out.println("Please enter a book id to get details");
			int id = sc.nextInt();
			b.setBookId(id);
			list.stream().filter(n -> n.getBookId() == b.getBookId()).forEach(System.out::println);

		} else
			System.out.println("This category does not exist");
	}
}
