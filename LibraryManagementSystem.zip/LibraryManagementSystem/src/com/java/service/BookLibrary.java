package com.java.service;

import java.util.List;

import com.java.dto.Book;

public interface BookLibrary {

	public List<Book> serachByCategory(Book book);
}
