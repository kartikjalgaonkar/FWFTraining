package com.java.serviceImpl;

import java.util.List;

import com.java.dao.BookDAO;
import com.java.dto.Book;
import com.java.service.BookLibrary;

public class HistoryBook implements BookLibrary {
	public HistoryBook() {

	}

	@Override
	public List<Book> serachByCategory(Book book) {
		BookDAO bd = new BookDAO();
		List<Book> bList = bd.getBookList(book);
		return bList;
	}

}
